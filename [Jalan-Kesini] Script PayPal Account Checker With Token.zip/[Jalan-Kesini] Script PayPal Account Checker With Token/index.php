<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en">
<head><link rel="shortcut icon" type="image/x-icon" href="icon.png"><title>PayPal Account Checker</title>
        <style>
                @import "http://fonts.googleapis.com/css?family=Play:400,700";
						.rainbow {

							-webkit-background-clip: text;
							-background-clip: text;
							-webkit-text-fill-color: transparent;
							-text-fill-color: transparent;
							background-image: -webkit-gradient( linear, left top, right top, color-stop(0, #f22), color-stop(0.15, #f2f), color-stop(0.3, #66f), color-stop(0.45, #2ff), color-stop(0.6, #2f2),color-stop(0.75, #2f2), color-stop(0.9, #ff2), color-stop(1, #f22) );
							background-image: gradient( linear, left top, right top, color-stop(0, #f22), color-stop(0.15, #f2f), color-stop(0.3, #66f), color-stop(0.45, #2ff), color-stop(0.6, #2f2),color-stop(0.75, #2f2), color-stop(0.9, #ff2), color-stop(1, #f22) );
							}
						.text-glow:hover, .text-glow:focus, .text-glow:active {
						   -webkit-stroke-width: 5.3px;
						   -webkit-stroke-color: #ccdddd;
						   -webkit-fill-color: #eeeeee;
						   text-shadow: 1px 0px 20px silver;
						   -webkit-transition: width 0.3s; /*Safari & Chrome*/
						   transition: width 0.3s;
						   -moz-transition: width 0.3s; /* Firefox 4 */
						   -o-transition: width 0.3s; /* Opera */
						   }
					   .text-glow a {
						   -webkit-transition: all 0.3s ease-in; /*Safari & Chrome*/
						   transition: all 0.3s ease-in;
						   -moz-transition: all 0.3s ease-in; /* Firefox 4 */
						   -o-transition: all 0.3s ease-in; /* Opera */
						   text-decoration:none;
						   color:white;
					   }
                        body {
                                background:    #000000;
                                line-height: 1;
                                color: #bbb;
                                font-family: "CONSOLAS";
                                font-size: 12px;
                                background:#080808;
								  -webkit-background-size: cover;
								  -moz-background-size: cover;
								  -o-background-size: cover;
								  background-size: cover;

                        }
                        textarea, input, select {
                                border:0;
                                BORDER-COLLAPSE:collapse;
                                border:double 2px #696969;
                                color:#fff;
                                background:#000000;
                                margin:0;
                                padding:2px 4px;
                                font-family: Lucida Console,Tahoma;
                                font-size:12px;
								box-shadow: 0 0 15px gray;
								-webkit-box-shadow: 0 0 15px gray;
								-moz-box-shadow: 0 0 15px blue;
                        }
                        .title{
                                color: #eee;
                                background:    black;
                                text-align:    center;
                                font-size:    120%;
                        }
                        .button{
                                color:#eee;
                        }
                        .tool{
                                color:lime;
                        }
                        header {
                                font-family: Lucida Console;
                                font-size: 12px;
                                text-align: center;
                                padding-top: 10px;
                                color: #626262;
                        }
						/* Gradient 1 */
						.ta10 {
							background: url(http://s15.postimg.org/jk9q3izqj/download.gif);
							background-color: black;
							background-repeat:no-repeat;
							background-size: 52% 100%;
							background-position: center;
							border:2px double #696969;
							padding:3px;
							margin-right:4px;
							margin-bottom:8px;
							font-family: Lucida Console,Tahoma;
                            font-size:12px;
							box-shadow: 0 0 5px white;
						   -webkit-box-shadow: 0 0 5px white;
						   -moz-box-shadow: 0 0 5px white;
						   border: solid 0px transparent; // or border: none;
						}
						
						
        </style>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="description" content="Paypal Account Checker - ApepBlack" />
	<meta name="author" content="Aldi Permana" />
	<title>PayPal Account Checker</title>
	<link href="style.css" rel="stylesheet" type="text/css" />
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.9.1/jquery-ui.min.js"></script>
    <script type="text/javascript" src="blockui.js"></script>

</head>
<body>
<header>
				
                
				<div><font color="red">Copyright <a href="http://fb.me/aldipermanans">ApepBlack<a> Thanks To IDBTe4m</font>
					<hr /><center><h1> <font color="#F8E6E0">SilentChild12</font> <h1> </center>
        <center><span id="howitswork">Public Tools</span> <br> <!-- <span id="idcoder">Coder : </span> <span id="email-coder">admin</span> --> <p>Contact : <a href="https://www.facebook.com/ferry.id.404" style="text-decoration: none;"><font color="red">Facebook<font color="#04B404"></a></p> </div> </center> 
                <hr /><br><font color="darkgreen" class="rainbow"><blink>USE IT OR LEAVE IT!</blink></font><br>
                </header>

<form method="post">
	<div align="center"><p class="rainbow">
                <!--Check eMail <input type="checkbox"  id="email" name="email" checked="checked" value="1" />-->
                Check Billing <input type="checkbox"  id="info" name="info" checked="checked" value="1" />
                Check Card <input type="checkbox"  id="card" name="card" checked="checked" value="1" />
                Check Bank <input type="checkbox"  id="bank" name="bank" checked="checked" value="1" />
                Check Last Payment <input type="checkbox"  id="payment" name="payment" checked="checked" value="1" />
                </p>
		<textarea name="mailpass" id="mailpass" cols="90" rows="10" style="background:rgba(0,225,0,00);"></textarea>
		<br />
		<font color="#F8E6E0">Input Delimeter</font> <input type="text" name="delim" id="delim" value="|" size="1" /><br><hr>
		<a href="http://gibrangates.tk/~paypal/token-paypal.php" target="_blank"><font color="#F8E6E0"><blink>Access Token Generator 1</blink></font></a><br>
		<a href="http://chk.codex2015.asia/token.php" target="_blank"><font color="#F8E6E0"><blink>Access Token Generator 2</blink></font></a><br><br>
		<font color="#F8E6E0">Acces Token</font> <br><input placeholder='AccessToken is needed by PayPal'  type="text" name="token" id="token" value="" size="40" style="margin-top: 5px;background:rgba(225,225,225,0.2);text-align:center" /><br>
<br />
             
		<input type="button" class = "submit-button" value="START" id="submit" />&nbsp;<input type="button" class="submit-button" value="STOP" id="stop" /><hr><br><div id="finish" style="display: none;"><center><i style='color:gold;font-size: 15px;'>~All process has been finished within <font id='time'>0</font> Minute~</i></center></div><br>
		<div id="result" style="display: none;"><center>
		<font size="3" color="silver" class="char"><i>Total: <b id='ctotal'>0</b> - Live: <b id='clive'>0</b> - Die: <b id='cdie'>0</b></i>
		</center></div>
		<div id="loading" style="display: none;"><center>Processing <font id="now"></font>/<font id="last"></font><br/><img src="http://s25.postimg.org/xgsbp2gof/loading.gif"/></center></div><br />
        <img id="loading" src="clear.gif" /><br />
        <span id="checkStatus" style="color: limegreen;"></span>
	</div>
</form>

<center>
<div id="data" style='display: none'><table style="width: 1024px;">
        <style>
@import "http://fonts.googleapis.com/css?family=Play:400,700";
						.rainbow {

							-webkit-background-clip: text;
							-background-clip: text;
							-webkit-text-fill-color: transparent;
							-text-fill-color: transparent;
							background-image: -webkit-gradient( linear, left top, right top, color-stop(0, #f22), color-stop(0.15, #f2f), color-stop(0.3, #66f), color-stop(0.45, #2ff), color-stop(0.6, #2f2),color-stop(0.75, #2f2), color-stop(0.9, #ff2), color-stop(1, #f22) );
							background-image: gradient( linear, left top, right top, color-stop(0, #f22), color-stop(0.15, #f2f), color-stop(0.3, #66f), color-stop(0.45, #2ff), color-stop(0.6, #2f2),color-stop(0.75, #2f2), color-stop(0.9, #ff2), color-stop(1, #f22) );
							}
						.text-glow:hover, .text-glow:focus, .text-glow:active {
						   -webkit-stroke-width: 5.3px;
						   -webkit-stroke-color: #ccdddd;
						   -webkit-fill-color: #eeeeee;
						   text-shadow: 1px 0px 20px silver;
						   -webkit-transition: width 0.3s; /*Safari & Chrome*/
						   transition: width 0.3s;
						   -moz-transition: width 0.3s; /* Firefox 4 */
						   -o-transition: width 0.3s; /* Opera */
						   }
					   .text-glow a {
						   -webkit-transition: all 0.3s ease-in; /*Safari & Chrome*/
						   transition: all 0.3s ease-in;
						   -moz-transition: all 0.3s ease-in; /* Firefox 4 */
						   -o-transition: all 0.3s ease-in; /* Opera */
						   text-decoration:none;
						   color:white;
					   }
                        body {
                                background-color: #000000;
    line-height: 1;
                                color: #bbb;
                                font-family: "CONSOLAS";
                                font-size: 12px;
                                //background-color:#080808;
                               background:#000000 no-repeat center center fixed;
								  -webkit-background-size: cover;
								  -moz-background-size: cover;
								  -o-background-size: cover;
								  background-size: cover;

                        }
                        textarea, input, select {
                                border:0;
                                BORDER-COLLAPSE:collapse;
                                border:double 2px #696969;
                                color:#fff;
                                background:#000000;
                                margin:0;
                                padding:2px 4px;
                                font-family: Lucida Console,Tahoma;
                                font-size:12px;
								box-shadow: 0 0 15px gray;
								-webkit-box-shadow: 0 0 15px gray;
								-moz-box-shadow: 0 0 15px blue;
                        }
                        .title{
                                color: #eee;
                                background:    black;
                                text-align:    center;
                                font-size:    120%;
                        }
                        .button{
                                color:#eee;
                        }
                        .tool{
                                color:lime;
                        }
                        header {
                                font-family: Lucida Console;
                                font-size: 12px;
                                text-align: center;
                                padding-top: 10px;
                                color: #626262;
                        }
						/* Gradient 1 */
						.ta10 {
							background: url(http://s15.postimg.org/jk9q3izqj/download.gif);
							background-color: black;
							background-repeat:no-repeat;
							background-size: 52% 100%;
							background-position: center;
							border:2px double #696969;
							padding:3px;
							margin-right:4px;
							margin-bottom:8px;
							font-family: Lucida Console,Tahoma;
                            font-size:12px;
							box-shadow: 0 0 5px white;
						   -webkit-box-shadow: 0 0 5px white;
						   -moz-box-shadow: 0 0 5px white;
						   border: solid 0px transparent; // or border: none;
						}
    </style>
        <tr>
      <td style="width: 1024px;">
             <div style="overflow:auto; width:1024px; height: 350px; font-size: 11px; color:gainsboro" >
                        <br /><br />
                        <div id="pplive"></div><br />
                        <hr /><br />
                        <div style="float: left; width: 99%;">
                                <center>
                                List Paypal Die(<b><i><font color='red' id='ppdie_count'>0</font></i></b>):<br /><textarea name="mailpass" id="ppdie" rows="10" style="width:90%;" wrap=off></textarea>
                                </center>
                        </div>
                        <br/>
                        <br/>
                        <br/>
                        <p><center><h3><font color="red"> Thanks to ApepBlack </font></h3></center><hr>
						</p>
                 </div></td> </tr></table></div>
<script type="text/javascript" src="script.js"></script>
</body>
</html>